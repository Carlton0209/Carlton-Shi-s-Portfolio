# FORM / LIGHT — source and attribution

This independent, AI-assisted CGI study uses an existing licensed car model. It is not a client commission and does not claim original vehicle modeling.

## Original asset

- Title: Car Concept
- Model and textures: Eric Chadwick
- Copyright: © 2024 Darmstadt Graphics Group GmbH
- Source: https://github.com/KhronosGroup/glTF-Sample-Assets/tree/main/Models/CarConcept
- Attribution metadata: https://github.com/KhronosGroup/glTF-Sample-Assets/blob/main/Models/CarConcept/metadata.json
- Model license: Creative Commons Attribution 4.0 International (CC BY 4.0)
- License: https://creativecommons.org/licenses/by/4.0/
- Legal text: https://creativecommons.org/licenses/by/4.0/legalcode

The source documentation describes a model originally begun from public-domain geometry by Unity Fan and adapted by Eric Chadwick / DGG. Credit above follows the distributed asset's current metadata.

The original GLB includes Khronos and 3D Commerce marks; those marks are excluded from the model's CC BY license. The original `CarConcept.glb` is retained locally as the reproducible input; the website ZIP includes the derivative scene and links to the original source. See the upstream logo terms: https://github.com/KhronosGroup/glTF-Sample-Assets/blob/main/LICENSES/LicenseRef-LegalMark-Khronos.txt . No affiliation or endorsement is implied.

## Changes in the rendered derivative

All imported material node graphs are rebuilt from procedural Principled shaders, so no original logo-bearing image textures are used in the rendered study. The steering-wheel emblem mesh is removed; the license-plate surface becomes a plain dark material. Vehicle mesh geometry otherwise remains the supplied asset, seated on the studio floor using its actual lowest vertex.

The derivative adds graphite paint, secondary panel, glass, rubber, metal and interior material treatments; a studio plane; four area lights; two cameras; a neutral-clay breakdown; and actual Cycles render passes. Camera placement and light intensities change for the rear view.

AI assistance was used to write and revise the Python scene-building script and direct the study. All displayed images are actual Blender renders. No photographic-plate integration, original automotive design, fluid simulation, or Houdini / V-Ray execution is claimed.

This is a look-development exercise on a sample asset. The source mesh has surface limitations, and the output should not be represented as a production-ready automotive CAD model or commissioned advertising campaign.

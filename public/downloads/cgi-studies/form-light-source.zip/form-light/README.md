# FORM / LIGHT

An independent automotive lighting and material study. See `sources.md` for model credit, license, changes and scope.

## Files

- `hero.png`: front three-quarter, 1600 × 1000.
- `alternate.png`: rear three-quarter, 1600 × 1000, with adjusted lighting.
- `clay.png`: real neutral-material render from the hero camera.
- `form-light.blend`: editable native scene, saved with original materials and hero camera.
- `build_automotive.py`: reproducible scene builder. Its input is the original `CarConcept.glb`, available from the linked upstream source. The website ZIP includes the standalone derivative scene rather than redistributing the original GLB.
- `render-metadata.json`: recorded software, rendering settings and outputs.
- `hero-multipass.exr`: local full-resolution layered render. The web source ZIP omits this large intermediate; the script regenerates it.

## Rebuild

Install Blender 5.2, download [CarConcept.glb](https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/CarConcept/glTF-Binary/CarConcept.glb) beside the script, then run from this folder:

```text
blender --background --factory-startup --python build_automotive.py -- --shot all
```

For a preview, use `--shot hero --preview`. To supply another location for the unmodified model, add `--asset "path/to/CarConcept.glb"`. The default input is the GLB beside the script; output files are written in the same folder. The configured renderer uses NVIDIA OptiX. If another machine has no compatible device, switch the saved scene to CPU or adapt the device block in the script.

The provided native scene uses no external textures. Render settings: Cycles, 72 samples, denoising, AgX Medium High Contrast, 1600 × 1000. Saved PNGs are 8-bit RGB. The hero layered EXR is 16-bit and includes the requested lighting, depth, normal and object-mask passes. No separate color-finishing composite is claimed.

Opening the `.blend` does not require running the build script. If rendering a downloaded scene, choose an output path on your own machine before rendering.

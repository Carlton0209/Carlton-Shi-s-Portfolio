"""FORM / LIGHT: reproducible, self-initiated automotive lighting study.

Run with Blender 5.2:
  blender --background --python build_automotive.py -- --shot all
  blender --background --python build_automotive.py -- --shot hero --preview

Source geometry: CarConcept, Eric Chadwick / Darmstadt Graphics Group GmbH.
This script authors the derivative's material treatment, stage, cameras and lights.
It does not claim authorship of the vehicle model. See sources.md.
"""
import argparse
import json
import math
from pathlib import Path
import sys

import bpy
from mathutils import Vector

OUT = Path(__file__).resolve().parent
DEFAULT_ASSET = OUT / 'CarConcept.glb'
args = argparse.ArgumentParser()
args.add_argument('--asset', type=Path, default=DEFAULT_ASSET)
args.add_argument('--shot', choices=['all', 'hero', 'alternate', 'clay'], default='all')
args.add_argument('--preview', action='store_true')
opts = args.parse_args(sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else [])

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(opts.asset))
scene = bpy.context.scene
vehicle = [o for o in scene.objects if o.type == 'MESH']
for name in ['InteriorSteeringEmblem']:
    obj = bpy.data.objects.get(name)
    if obj:
        vehicle.remove(obj)
        bpy.data.objects.remove(obj, do_unlink=True)

def shader(name, color, metallic=0, roughness=.4, coat=0, transmission=0, emission=None):
    material = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    material.use_nodes = True
    nodes = material.node_tree.nodes
    nodes.clear()
    surface = nodes.new('ShaderNodeBsdfPrincipled')
    surface.inputs['Base Color'].default_value = (*color, 1)
    surface.inputs['Metallic'].default_value = metallic
    surface.inputs['Roughness'].default_value = roughness
    surface.inputs['Coat Weight'].default_value = coat
    surface.inputs['Coat Roughness'].default_value = .22
    surface.inputs['Transmission Weight'].default_value = transmission
    surface.inputs['IOR'].default_value = 1.47 if transmission else 1.5
    if emission:
        surface.inputs['Emission Color'].default_value = (*emission[0], 1)
        surface.inputs['Emission Strength'].default_value = emission[1]
    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (320, 0)
    material.node_tree.links.new(surface.outputs['BSDF'], output.inputs['Surface'])
    return material

# Completely rebuild imported material graphs; no original logo-bearing textures
# or texture normal maps are retained in this derivative scene.
for material in list(bpy.data.materials):
    name = material.name
    if name.startswith('Paint 1'):
        shader(name, (.065, .073, .078), metallic=.72, roughness=.32, coat=.32)
    elif name.startswith('Paint 2'):
        shader(name, (.032, .038, .039), metallic=.55, roughness=.28, coat=.4)
    elif name == 'Glass':
        shader(name, (.76, .83, .86), roughness=.065, transmission=1)
    elif name == 'Mirror':
        shader(name, (.72, .75, .77), metallic=1, roughness=.055)
    elif name == 'Rim1':
        shader(name, (.44, .46, .47), metallic=1, roughness=.26)
    elif name == 'Rim2':
        shader(name, (.035, .042, .046), metallic=.85, roughness=.3)
    elif name in ['Disc', 'Hardware']:
        shader(name, (.31, .32, .33), metallic=.95, roughness=.35)
    elif name in ['Tireside', 'Tiretread']:
        shader(name, (.012, .015, .017), roughness=.63)
    elif name == 'Headlight':
        shader(name, (.34, .4, .45), metallic=.6, roughness=.14,
               emission=((.80, .90, 1.0), .45))
    elif name == 'Brakelight':
        shader(name, (.16, .009, .003), roughness=.2, coat=.6)
    elif name == 'Signallight':
        shader(name, (.18, .045, .006), roughness=.23, coat=.5)
    elif name == 'Brake':
        shader(name, (.13, .065, .028), metallic=.45, roughness=.37)
    elif name.startswith('Interior 3'):
        shader(name, (.075, .047, .026), roughness=.52)
    elif name == 'Dashboard':
        shader(name, (.009, .018, .023), roughness=.3)
    elif name == 'License':
        shader(name, (.021, .026, .028), metallic=.4, roughness=.4)
    else:
        shader(name, (.018, .022, .024), metallic=.12, roughness=.48)

for im in list(bpy.data.images):
    if im.users == 0:
        bpy.data.images.remove(im)

# Seat the original model on the floor without changing its dimensions.
bpy.context.view_layer.update()
bottom = min((o.matrix_world @ v.co).z for o in vehicle for v in o.data.vertices)
root_objects = [o for o in scene.objects if o.parent is None]
for obj in root_objects:
    obj.location.z -= bottom
bpy.context.view_layer.update()

floor = shader('STUDIO / warm mineral floor', (.18, .18, .17), roughness=.5)
bpy.ops.mesh.primitive_plane_add(size=2000, location=(0, 0, -.006))
ground = bpy.context.object
ground.name = 'STUDIO / seamless floor'
ground.data.materials.append(floor)

world = bpy.data.worlds.new('STUDIO / ambient')
scene.world = world
world.use_nodes = True
world.node_tree.nodes['Background'].inputs['Color'].default_value = (.38, .40, .43, 1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value = .45

def aim(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()

def area(name, position, target, energy, size, size_y, color):
    data = bpy.data.lights.new(name, type='AREA')
    data.energy = energy
    data.shape = 'RECTANGLE'
    data.size = size
    data.size_y = size_y
    data.color = color
    obj = bpy.data.objects.new(name, data)
    scene.collection.objects.link(obj)
    obj.location = position
    aim(obj, target)
    return obj

lights = {}
lights['key'] = area('LIGHT / overhead softbox', (-3.0, -1.0, 5.5), (0, -.7, .6),
                     1000, 2.5, 6.0, (1, .94, .86))
lights['side'] = area('LIGHT / long side strip', (4.1, 1.2, 4.0), (0, -.1, .8),
                      650, 1.6, 5.5, (.88, .94, 1))
lights['front'] = area('LIGHT / front fill', (1.4, -5.8, 3.1), (0, -.8, .6),
                       500, 5.0, 3.0, (1, .96, .90))
lights['rim'] = area('LIGHT / rear edge', (-4.0, 3.0, 1.6), (0, .4, .8),
                     180, 3.0, 4.0, (1, .90, .78))

def camera(name, position, target, lens):
    data = bpy.data.cameras.new(name)
    obj = bpy.data.objects.new(name, data)
    scene.collection.objects.link(obj)
    obj.location = position
    aim(obj, target)
    data.lens = lens
    data.sensor_width = 36
    data.clip_end = 500
    return obj

hero = camera('CAMERA / hero front three-quarter', (6.7, -8.8, 2.6), (0, -.20, .56), 66)
alternate = camera('CAMERA / alternate rear three-quarter', (-6.6, 7.9, 2.75), (0, -.10, .62), 57)
scene.camera = hero

scene.render.engine = 'CYCLES'
preferences = bpy.context.preferences.addons['cycles'].preferences
preferences.compute_device_type = 'OPTIX'
preferences.get_devices()
devices = []
for device in preferences.devices:
    device.use = device.type == 'OPTIX'
    if device.use:
        devices.append(device.name)
scene.cycles.device = 'GPU'
scene.cycles.samples = 24 if opts.preview else 72
scene.cycles.use_denoising = True
scene.cycles.max_bounces = 10
scene.cycles.transmission_bounces = 8
scene.cycles.transparent_max_bounces = 8
scene.cycles.seed = 19
scene.render.resolution_x = 1600
scene.render.resolution_y = 1000
scene.render.resolution_percentage = 50 if opts.preview else 100
scene.render.film_transparent = False
scene.view_settings.view_transform = 'AgX'
scene.view_settings.look = 'AgX - Medium High Contrast'
scene.view_settings.exposure = 0
scene.render.image_settings.color_mode = 'RGB'
scene.render.image_settings.color_depth = '8'
scene.render.image_settings.file_format = 'PNG'
scene.render.fps = 24

layer = bpy.context.view_layer
layer.use_pass_z = True
layer.use_pass_normal = True
layer.use_pass_diffuse_color = True
layer.use_pass_diffuse_direct = True
layer.use_pass_glossy_direct = True
layer.use_pass_glossy_indirect = True
layer.use_pass_transmission_direct = True
layer.use_pass_transmission_indirect = True
layer.use_pass_emit = True
layer.use_pass_cryptomatte_object = True
layer.pass_cryptomatte_depth = 6

scene['Project'] = 'FORM / LIGHT — Automotive lighting study'
scene['Disclosure'] = 'Self-initiated, AI-assisted CGI study. Original vehicle model by Eric Chadwick / DGG; derivative studio materials, cameras and lighting authored with a Python script.'
scene['License'] = 'CarConcept: CC BY 4.0. Original textures and steering emblem removed. See sources.md.'
scene['Not_claimed'] = 'Original car modeling, client commission, photographic plate integration, fluid simulation, V-Ray or Houdini execution.'

clay = shader('BREAKDOWN / neutral clay', (.32, .34, .35), roughness=.58)
original_slots = {o.name: list(o.data.materials) for o in vehicle}
original_lights = {key: (o.data.energy, tuple(o.data.color)) for key, o in lights.items()}

def configure(shot):
    for o in vehicle:
        for i, mat in enumerate(original_slots[o.name]):
            o.data.materials[i] = clay if shot == 'clay' else mat
    for key, obj in lights.items():
        obj.data.energy, obj.data.color = original_lights[key]
    scene.camera = alternate if shot == 'alternate' else hero
    if shot == 'alternate':
        lights['key'].data.energy = 1500
        lights['side'].data.energy = 2350
        lights['rim'].data.energy = 900
        lights['rim'].data.color = (.80, .89, 1)
        lights['front'].data.energy = 350

configure('hero')
if not opts.preview:
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT / 'form-light.blend'))

shots = ['hero', 'alternate', 'clay'] if opts.shot == 'all' else [opts.shot]
for shot in shots:
    configure(shot)
    suffix = '-preview' if opts.preview else ''
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_depth = '8'
    scene.render.filepath = str(OUT / f'{shot}{suffix}.png')
    print(f'RENDER_START {shot} device={devices} samples={scene.cycles.samples}', flush=True)
    bpy.ops.render.render(write_still=True)
    if shot == 'hero' and not opts.preview:
        scene.render.image_settings.media_type = 'MULTI_LAYER_IMAGE'
        scene.render.image_settings.file_format = 'OPEN_EXR_MULTILAYER'
        scene.render.image_settings.color_depth = '16'
        scene.render.image_settings.exr_codec = 'ZIP'
        bpy.data.images['Render Result'].save_render(str(OUT / 'hero-multipass.exr'), scene=scene)
        scene.render.image_settings.media_type = 'IMAGE'
        scene.render.image_settings.file_format = 'PNG'
        scene.render.image_settings.color_depth = '8'
    print(f'RENDER_DONE {shot}', flush=True)

configure('hero')
if not opts.preview:
    scene.render.filepath = str(OUT / 'hero.png')
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT / 'form-light.blend'))
    metadata = {
        'project': 'FORM / LIGHT', 'software': bpy.app.version_string,
        'engine': 'Cycles', 'devices': devices, 'samples': scene.cycles.samples,
        'resolution': [1600, 1000], 'color_management': 'AgX / Medium High Contrast',
        'shots_rendered_this_run': shots,
        'model_asset': str(opts.asset),
        'authorship': 'AI-assisted derivative lighting, material and camera study; supplied CC BY vehicle model.',
        'outputs': ['hero.png','alternate.png','clay.png','hero-multipass.exr','form-light.blend'],
    }
    (OUT / 'render-metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf8')

print('FORM_LIGHT_COMPLETE', flush=True)

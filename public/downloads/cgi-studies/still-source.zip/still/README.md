# STILL — Citrus mineral soda

An independent beverage visualization study for a fictional brand. The scene pairs pale lime packaging, dark green typography, aluminum trim, static condensation beads and a modeled yuzu cross section in a soft studio setting.

This project was made with AI-assisted Python scene authoring and visual direction, then rendered from real Blender geometry with Cycles. It is not a client commission. No AI-generated raster images, stock photography, downloaded 3D assets or external image textures are used.

## Delivered assets

- `hero.png`: 1440 × 900 landscape beauty render.
- `detail.png`: 1200 × 1200 close view of the lid, lacquer, typography and condensation.
- `clay.png`: 1440 × 900 neutral material override, using the exact hero camera, geometry and lighting. This is a real scene breakdown.
- `STILL_beverage_study.blend`: editable native Blender scene, saved with the hero camera and original materials.
- `build_beverage.py`: seeded reproducible builder and render script.
- `provenance.json`: render configuration, scene counts and disclosure.

## What was actually built

The can is a lathed profile with separate rolled rim, stamped top, inset aperture shape, pull tab and rivet. Typography is generated from Windows Arial and Arial Narrow Bold, converted into subdivided mesh geometry, and wrapped around the cylindrical body. The native `.blend` therefore contains mesh lettering rather than an external label texture.

Condensation is placed through a seeded Python distribution of linked droplet meshes. Droplets use a transmissive material with water IOR 1.333. Placement is lightly thinned across the primary brand type for legibility. Ground water beads use the same source mesh. These are static modeled beads, not a fluid or condensation simulation.

The citrus is a geometric study: a revolved half rind, pith, ten segmented cut faces and 900 small modeled juice vesicles. The leaf is a curved mesh with a modeled midrib. The citrus and leaf are stylized procedural approximations rather than scanned botanical assets.

Lacquer, peel, leaf and porcelain microstructure use procedural noise and bump nodes. Four area lights shape the studio reflections. The world provides a small amount of ambient fill. There is no HDRI or compositing pass.

## Rendering and reproducibility

Rendered in Blender 5.2.1 LTS, Cycles, NVIDIA OptiX on the available RTX 4080 Laptop GPU. Settings: 96 samples, adaptive threshold 0.025, denoising enabled, 10 maximum bounces and 8 transmission bounces. Color management: AgX, Medium High Contrast, exposure 0. PNG outputs are 8-bit RGB.

From PowerShell:

```powershell
& 'C:\Program Files\Blender Foundation\Blender 5.2\blender.exe' --background --python 'D:\Codex\Workspaces\thelab-cgi-studies\beverage\build_beverage.py' -- all
```

Use `hero`, `detail` or `clay` in place of `all` to rebuild and render one output. The builder reads Arial font files from `C:/Windows/Fonts`; adapt those two paths for other operating systems. It detects OptiX and falls back to CPU if setup fails. All generated assets are written beside the script. Random seed: 270.

## Portfolio language

Suggested title: **STILL — Beverage CGI Study**

Suggested description: **An independent study in beverage packaging, material response and studio lighting. A scripted Blender scene brings together lacquered aluminum, curved typography and procedural condensation, with a close-up and matching clay breakdown. AI assisted the scene authoring and iteration; final imagery was rendered in Cycles.**

Suggested tags: **Blender · Cycles · Product visualization · Procedural modeling · Lighting**

中文说明：这是虚构品牌的自主饮品 CGI 练习，使用 AI 辅助编写 Blender 脚本，全部画面由真实三维几何和材质渲染。水珠为程序化摆放的静态网格，未进行流体模拟；不应描述成真实客户项目、真实产品上市案例或用户本人独立手工完成的商业项目。

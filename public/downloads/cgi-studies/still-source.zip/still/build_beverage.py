"""STILL — independent procedural beverage CGI study. Blender 5.2.
Run: blender --background --python build_beverage.py -- [hero|detail|clay|all]
All image content is rendered from native scene geometry. No AI image textures.
"""
import bpy, bmesh, math, random, sys, os, json
from mathutils import Vector
from math import sin, cos, pi

ROOT=os.path.dirname(os.path.abspath(__file__))
random.seed(270)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for block in bpy.data.materials: bpy.data.materials.remove(block)

def srgb(h):
    h=h.lstrip('#'); c=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    return tuple(((v+.055)/1.055)**2.4 if v>.04045 else v/12.92 for v in c)
def material(name, color, rough=.4, metal=0, transmission=0):
    m=bpy.data.materials.new(name); m.use_nodes=True; m.node_tree.nodes.clear()
    p=m.node_tree.nodes.get('Principled BSDF') or m.node_tree.nodes.new('ShaderNodeBsdfPrincipled'); p.name='Principled BSDF'
    out=m.node_tree.nodes.get('Material Output') or m.node_tree.nodes.new('ShaderNodeOutputMaterial')
    m.node_tree.links.new(p.outputs['BSDF'],out.inputs['Surface'])
    p.inputs['Base Color'].default_value=(*srgb(color),1)
    p.inputs['Roughness'].default_value=rough; p.inputs['Metallic'].default_value=metal
    p.inputs['Transmission Weight'].default_value=transmission
    return m
lime=material('01 | satin pale-lime lacquer','#c8d47a',.29,.32)
ink=material('02 | forest-green printed typography','#193e2f',.38,.05)
silver=material('03 | brushed aluminum','#c9d0cb',.225,.98)
darkmetal=material('04 | lid recessed shadow','#6b7872',.29,.95)
water=material('05 | condensation / water IOR 1.333','#ffffff',.045,0,1)
water.node_tree.nodes.get('Principled BSDF').inputs['IOR'].default_value=1.333
rind=material('06 | yuzu rind','#ead63b',.47)
pith=material('07 | citrus pith','#f5f0cf',.73)
pulp=material('08 | translucent citrus flesh','#eac546',.24,0,.32)
pulp.node_tree.nodes.get('Principled BSDF').inputs['Subsurface Weight'].default_value=.1
pulp.node_tree.nodes.get('Principled BSDF').inputs['Subsurface Radius'].default_value=(.12,.08,.04)
leafmat=material('09 | waxy yuzu leaf','#2b5227',.3)
stone=material('10 | warm porcelain plinth','#e7e3cb',.35)
ground=material('11 | pale citrus seamless','#e6e9cf',.62)

# Microstructure remains procedural, including lacquer, peel, leaf and porcelain.
for mat,scale,strength,distance in [(lime,165,.13,.008),(rind,38,.48,.025),(stone,72,.16,.014),(leafmat,85,.14,.009)]:
    nt=mat.node_tree; n=nt.nodes.new('ShaderNodeTexNoise'); n.inputs['Scale'].default_value=scale
    n.inputs['Detail'].default_value=3; b=nt.nodes.new('ShaderNodeBump'); b.inputs['Strength'].default_value=strength
    b.inputs['Distance'].default_value=distance; nt.links.new(n.outputs['Fac'],b.inputs['Height']); nt.links.new(b.outputs['Normal'],nt.nodes.get('Principled BSDF').inputs['Normal'])

def mesh_obj(name, verts, faces, mat=None):
    me=bpy.data.meshes.new(name); me.from_pydata(verts,[],faces); me.update()
    ob=bpy.data.objects.new(name,me); bpy.context.collection.objects.link(ob)
    if mat: me.materials.append(mat)
    for p in me.polygons:p.use_smooth=True
    return ob
def parent(ob,group): ob.parent=group; return ob
def lathe(name,profile,mat,n=192):
    verts=[(r*cos(2*pi*j/n),r*sin(2*pi*j/n),z) for r,z in profile for j in range(n)]
    faces=[]
    for k in range(len(profile)-1):
        for j in range(n):faces.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
    faces.extend([tuple(range(n-1,-1,-1)),tuple((len(profile)-1)*n+j for j in range(n))])
    return mesh_obj(name,verts,faces,mat)
def torus(name,r,minor,z,mat,group=None):
    bpy.ops.mesh.primitive_torus_add(major_radius=r,minor_radius=minor,major_segments=128,minor_segments=16,location=(0,0,z))
    ob=bpy.context.object;ob.name=name;ob.data.materials.append(mat)
    for p in ob.data.polygons:p.use_smooth=True
    if group:parent(ob,group)
    return ob
def cylinder(name,r,depth,z,mat,group=None):
    bpy.ops.mesh.primitive_cylinder_add(vertices=128,radius=r,depth=depth,location=(0,0,z))
    ob=bpy.context.object;ob.name=name;ob.data.materials.append(mat)
    bevel=ob.modifiers.new('Manufactured edge','BEVEL');bevel.width=.012;bevel.segments=3
    for p in ob.data.polygons:p.use_smooth=True
    if group:parent(ob,group)
    return ob
def curve(name,points,bevel,mat,group=None):
    cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.bevel_depth=bevel;cu.bevel_resolution=3
    sp=cu.splines.new('POLY');sp.points.add(len(points)-1)
    for p,co in zip(sp.points,points):p.co=(*co,1)
    ob=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(ob);cu.materials.append(mat)
    if group:parent(ob,group)
    return ob

can=bpy.data.objects.new('STILL | complete can assembly',None);bpy.context.collection.objects.link(can)
profile=[(.57,.045),(.65,.045),(.69,.075),(.715,.12),(.735,.22),(.76,.33),(.76,2.91),(.752,3.0),(.72,3.09),(.666,3.19),(.666,3.235)]
body=parent(lathe('Can body | revolved aluminum profile',profile,lime),can)
torus('Bottom rolled seam',.655,.027,.075,silver,can)
torus('Upper rolled aluminum rim',.671,.031,3.255,silver,can)
cylinder('Stamped aluminum top',.657,.027,3.242,silver,can)
torus('Stamped inner concentric ring',.565,.009,3.264,darkmetal,can)
torus('Stamped inner highlight',.548,.008,3.267,silver,can)

# Opening and pull tab, both geometry rather than painted top textures.
opening=cylinder('Drink aperture | recessed geometry',.19,.008,3.265,darkmetal,can);opening.scale=(.78,1.5,1);opening.location.y=-.24
tab=torus('Pull tab oval outer',.165,.043,3.295,silver,can);tab.scale=(.72,1.32,.52);tab.location.y=.07
cylinder('Pull tab rivet',.055,.026,3.291,silver,can)
curve('Tab bridge',[(-.11,.08,3.292),(.11,.08,3.292)],.035,silver,can)

font_reg=bpy.data.fonts.load('C:/Windows/Fonts/arial.ttf')
font_bold=bpy.data.fonts.load('C:/Windows/Fonts/ARIALNB.TTF')
def label(text,z,size,font=font_reg,spacing=1.05,name=None):
    cu=bpy.data.curves.new(name or text,'FONT');cu.body=text;cu.align_x='CENTER';cu.size=size;cu.space_character=spacing;cu.font=font
    cu.resolution_u=12;cu.extrude=.00025
    ob=bpy.data.objects.new(name or 'Print | '+text,cu);bpy.context.collection.objects.link(ob)
    bpy.context.view_layer.objects.active=ob;ob.select_set(True)
    bpy.ops.object.convert(target='MESH');ob=bpy.context.object
    # Triangulate and subdivide so curved glyph faces never cut into the can.
    bm=bmesh.new();bm.from_mesh(ob.data);bmesh.ops.triangulate(bm,faces=list(bm.faces))
    bmesh.ops.subdivide_edges(bm,edges=list(bm.edges),cuts=4,use_grid_fill=True);bm.to_mesh(ob.data);bm.free()
    # Arc-wrap the real glyph geometry to the can surface.
    for v in ob.data.vertices:
        x,y,depth=v.co;theta=x/.764;r=.765+depth;v.co=(r*sin(theta),-r*cos(theta),y+z)
    ob.data.materials.append(ink);parent(ob,can);ob.select_set(False)
    return ob
label('A MOMENT OF',2.68,.092,spacing=1.3)
label('BRIGHTNESS.',2.53,.092,spacing=1.3)
label('STILL',1.91,.67,font_bold,1.0)
label('YUZU + LIME',1.63,.112,font_bold,1.2)
label('CITRUS MINERAL SODA',.63,.078,spacing=1.08)
label('330 mL  /  SMALL-BATCH SPARKLE',.44,.049,spacing=1.08)
def wrap_graphic(name,xy,mat,thickness=.008):
    return curve(name,[(.766*sin(x/.766),-.766*cos(x/.766),z) for x,z in xy],thickness,mat,can)
wrap_graphic('Printed fine rule',[(-.46,1.46),(.46,1.46)],ink,.003)
# Minimal citrus mark: paired fruit outlines and leaf.
for cx,cz,r in [(-.105,1.075,.19),(.145,1.035,.15)]:
    wrap_graphic('Citrus line icon',[(cx+r*cos(a*2*pi/96),cz+r*sin(a*2*pi/96)) for a in range(97)],ink,.007)
wrap_graphic('Citrus icon stem',[(-.12,1.265),(-.09,1.36),(.02,1.4),(.08,1.35),(-.09,1.36)],ink,.006)

# Shared droplet mesh, linked instances. Distribution is deliberate and reproducible.
bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=1)
drop_template=bpy.context.object;drop_template.name='Water droplet source (hidden)';drop_template.data.materials.append(water)
for p in drop_template.data.polygons:p.use_smooth=True
drop_template.hide_render=True;drop_template.hide_viewport=True
for i in range(430):
    a=random.uniform(-pi,pi);z=random.uniform(.3,3.03)
    radius=random.choices([random.uniform(.008,.017),random.uniform(.018,.031),random.uniform(.032,.047)],[.63,.30,.07])[0]
    # Keep major letters legible while retaining a few tiny beads on the face.
    if abs(a)<.9 and 1.58<z<2.47 and radius>.018:continue
    ob=bpy.data.objects.new('Condensation bead %03d'%i,drop_template.data);bpy.context.collection.objects.link(ob)
    ob.location=(.765*sin(a),-.765*cos(a),z)
    # Local Y follows surface normal; flattened contact in radial direction.
    ob.scale=(radius,radius*.48,radius*random.uniform(1,1.35));ob.rotation_euler[2]=a
    parent(ob,can)
can.location=(.32,.12,.01);can.rotation_euler[2]=math.radians(12)

# Citrus cross section: rind/pith rings, individual radial segments and juice vesicles.
fruit=bpy.data.objects.new('Yuzu half | cut citrus assembly',None);bpy.context.collection.objects.link(fruit)
shell=lathe('Yuzu rind | rounded half fruit',[(.04,-.57),(.25,-.53),(.44,-.4),(.56,-.2),(.58,0)],rind,128);parent(shell,fruit)
cylinder('Yuzu pale pith cross section',.557,.025,.005,pith,fruit)
cylinder('Yuzu center pith',.065,.045,.027,pith,fruit)
segments=10
for k in range(segments):
    a0=2*pi*k/segments+.027;a1=2*pi*(k+1)/segments-.027
    steps=15;vs=[(.07*cos(a0),.07*sin(a0),.033)]
    for j in range(steps+1):
        a=a0+(a1-a0)*j/steps;vs.append((.509*cos(a),.509*sin(a),.03))
    vs.append((.07*cos(a1),.07*sin(a1),.033))
    ob=mesh_obj('Citrus pulp segment %02d'%k,vs,[tuple(range(len(vs)))],pulp);parent(ob,fruit)
    # Explicit pulp vesicle geometry creates dimensional, backlit flesh.
    for j in range(90):
        a=random.uniform(a0+.02,a1-.02);r=random.uniform(.105,.48)
        ob=bpy.data.objects.new('Juice vesicle %02d.%02d'%(k,j),drop_template.data.copy());bpy.context.collection.objects.link(ob)
        ob.data.materials.clear();ob.data.materials.append(pulp)
        ob.location=(r*cos(a),r*sin(a),random.uniform(.027,.037));ob.scale=(random.uniform(.018,.032),.008,.007);ob.rotation_euler[2]=a;parent(ob,fruit)
fruit.rotation_euler=(math.radians(77),math.radians(-12),math.radians(8));fruit.location=(-.96,-.24,.57)

# A single fallen leaf with midrib and curved silhouette.
verts=[];faces=[];N=32
for i in range(N+1):
    t=i/N;x=t*1.4;w=.31*sin(pi*t)**.8;z=.10*sin(pi*t)
    verts.extend([(x,-w,z-.06*sin(pi*t)),(x,0,z+.025),(x,w,z-.06*sin(pi*t))])
for i in range(N):
    a=i*3;faces.extend([(a,a+3,a+4,a+1),(a+1,a+4,a+5,a+2)])
leaf=mesh_obj('Yuzu leaf',verts,faces,leafmat);leaf.location=(-1.6,.24,.035);leaf.rotation_euler[2]=math.radians(151)
sol=leaf.modifiers.new('Thin leaf thickness','SOLIDIFY');sol.thickness=.006
vein=curve('Leaf central rib',[(i/N*1.4,0,.10*sin(pi*i/N)+.031) for i in range(N+1)],.008,leafmat)
vein.location=leaf.location;vein.rotation_euler=leaf.rotation_euler

# Low porcelain platform and an infinite studio sweep.
bpy.ops.mesh.primitive_cube_add(size=1,location=(.0,.25,-.145));plinth=bpy.context.object;plinth.name='Porcelain display block'
plinth.dimensions=(4.45,2.85,.29);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
plinth.data.materials.append(stone);bev=plinth.modifiers.new('Soft porcelain edge','BEVEL');bev.width=.065;bev.segments=5
for p in plinth.data.polygons:p.use_smooth=True
plinth.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.3));bpy.context.object.name='Seamless studio ground';bpy.context.object.data.materials.append(ground)

# A few physically modeled water beads on the porcelain.
for i in range(29):
    x=random.uniform(-1.9,1.6);y=random.uniform(-1.0,.55)
    if (x-.32)**2+(y-.12)**2<.65:continue
    ob=bpy.data.objects.new('Fallen water bead %02d'%i,drop_template.data);bpy.context.collection.objects.link(ob)
    ob.location=(x,y,.013);r=random.uniform(.015,.042);ob.scale=(r*1.2,r,.4*r)

def aim(ob,point):ob.rotation_euler=(Vector(point)-ob.location).to_track_quat('-Z','Y').to_euler()
def area(name,loc,power,size,color,target=(0,0,1.3),shape='DISK',size_y=None):
    d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape=shape;d.size=size;d.color=color
    if size_y and shape=='RECTANGLE':d.size_y=size_y
    o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc;aim(o,target)
    return o
area('Key | large silk left',(-3.7,-4.6,7),900,4.5,(1,.94,.79))
area('Rim | tall cool strip',(3.6,1.5,5.1),850,2.3,(.88,1,.90),shape='RECTANGLE',size_y=5)
area('Front typography fill',(.4,-5.5,3.9),150,3,(1,1,.94))
area('Top aluminum softbox',(-.6,1.5,7.2),650,3,(1,1,1))

scene=bpy.context.scene
world=bpy.data.worlds.new('Warm studio ambience');scene.world=world;world.use_nodes=True;world.node_tree.nodes.clear()
bg=world.node_tree.nodes.get('Background') or world.node_tree.nodes.new('ShaderNodeBackground')
wo=world.node_tree.nodes.get('World Output') or world.node_tree.nodes.new('ShaderNodeOutputWorld')
world.node_tree.links.new(bg.outputs['Background'],wo.inputs['Surface'])
bg.inputs['Color'].default_value=(.72,.78,.64,1);bg.inputs['Strength'].default_value=.16
bpy.ops.object.camera_add(location=(4.8,-10.8,6.4));cam=bpy.context.object;cam.name='Camera | hero';aim(cam,(-.05,0,1.43));cam.data.type='ORTHO';cam.data.ortho_scale=7.8;scene.camera=cam
bpy.ops.object.camera_add(location=(2.85,-5.6,5.3));detail=bpy.context.object;detail.name='Camera | material detail';aim(detail,(.32,.05,2.28));detail.data.type='ORTHO';detail.data.ortho_scale=2.95
scene.render.engine='CYCLES';scene.cycles.samples=96;scene.cycles.use_denoising=True
scene.cycles.max_bounces=10;scene.cycles.transmission_bounces=8;scene.cycles.transparent_max_bounces=8
scene.cycles.adaptive_threshold=.025
try:
    cp=bpy.context.preferences.addons['cycles'].preferences;cp.compute_device_type='OPTIX';cp.get_devices()
    for d in cp.devices:d.use=d.type=='OPTIX'
    scene.cycles.device='GPU'
except Exception:scene.cycles.device='CPU'
scene.render.resolution_x=1440;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.film_transparent=False
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.0
scene.render.image_settings.color_depth='8'
scene.render.engine='CYCLES'
scene['study_disclosure']='Independent fictional-brand CGI study; AI-assisted Python scene authoring. Native Blender geometry/materials, no AI-generated raster, no client commission, no fluid simulation.'
scene['condensation_method']='430 seeded linked mesh droplet candidates, selectively thinned over brand typography; static geometry, not simulated condensation.'
scene['typefaces']='Arial and Arial Narrow Bold loaded from Windows system fonts.'
manifest={
    'project':'STILL / Citrus mineral soda',
    'classification':'Independent fictional-brand CGI study',
    'software':bpy.app.version_string,
    'render_engine':'Cycles','device':scene.cycles.device,'samples':scene.cycles.samples,
    'denoising':True,'view_transform':'AgX','look':scene.view_settings.look,
    'hero_dimensions':[1440,900],'detail_dimensions':[1200,1200],'clay_dimensions':[1440,900],
    'droplet_instances':sum(o.name.startswith('Condensation bead') for o in bpy.data.objects),
    'citrus_vesicle_meshes':sum(o.name.startswith('Juice vesicle') for o in bpy.data.objects),
    'scene_objects':len(bpy.data.objects),
    'random_seed':270,'ai_role':'AI-assisted Python scene authoring and art direction',
    'raster_generation':False,'fluid_simulation':False,'third_party_3d_assets':False,
    'typography':'Arial / Arial Narrow Bold; Windows system fonts, converted to mesh in the scene',
    'breakdown':'Clay uses the exact hero camera, geometry and lighting with a neutral material override.'
}
with open(os.path.join(ROOT,'provenance.json'),'w',encoding='utf-8') as f:json.dump(manifest,f,indent=2,ensure_ascii=False)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'STILL_beverage_study.blend'))

mode=sys.argv[sys.argv.index('--')+1] if '--' in sys.argv and len(sys.argv)>sys.argv.index('--')+1 else 'all'
def render(name):
    scene.render.filepath=os.path.join(ROOT,name+'.png');bpy.ops.render.render(write_still=True)
if mode in ['all','hero']:render('hero')
if mode in ['all','detail']:
    scene.camera=detail;scene.render.resolution_x=1200;scene.render.resolution_y=1200;render('detail')
if mode in ['all','clay']:
    scene.camera=cam;scene.render.resolution_x=1440;scene.render.resolution_y=900
    clay=material('BREAKDOWN | neutral clay override','#bcbdb3',.58)
    bpy.context.view_layer.material_override=clay;render('clay');bpy.context.view_layer.material_override=None
print('STILL render complete:',mode,flush=True)

# VELISE — AI hand-off kit

Everything needed to take the 3D render into an AI pass without changing the product.

| File | What it is |
| --- | --- |
| `VELISE_hero.png` | Path-traced beauty render, hero camera, 1200 × 1500 |
| `VELISE_hero_mask.png` | Product mask: white = bottle, black = set |
| `VELISE_hero_depth.png` | Depth pass: white = near, black = far |
| `VELISE_hero_normal.png` | View-space normal pass |
| `VELISE_set-rebuild_comfyui-api.json` | ComfyUI graph (API format, core nodes only) |
| `VELISE_motion-prompts.md` | Image-to-video prompts for Sora, Veo, Kling and Runway |

## Still: rebuild the set, keep the product

1. Copy the four PNGs into `ComfyUI/input/`.
2. Load `VELISE_set-rebuild_comfyui-api.json` (drag it onto the canvas, or POST it to `/prompt`).
3. Set the checkpoint and the SDXL depth ControlNet names to the files you have.
4. Queue. The graph encodes the beauty render, guides the new set with the depth pass at strength 0.7, samples at denoise 0.6, and composites the original product back through the mask.

Tuning: raise `denoise` for a bolder set, lower ControlNet `strength` for looser composition. The composited glass still shows the original set through it; for a fully matched refraction, mask only the cap, collar and label and let the model redraw the glass at denoise 0.35.

## Motion

See `VELISE_motion-prompts.md`. Use `VELISE_hero.png` as the first frame.

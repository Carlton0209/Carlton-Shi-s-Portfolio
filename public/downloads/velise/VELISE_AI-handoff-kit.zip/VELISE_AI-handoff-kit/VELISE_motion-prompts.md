# VELISE — image-to-video prompts

First frame for every prompt: `VELISE_hero.png` (4:5). Generate at 1080 × 1350 or the closest the model offers.
Each prompt moves only the camera and the light. The bottle, cap, collar, label text and juice level must not change.

## 1. Light sweep reveal (5 s)

Static locked-off camera. A narrow band of warm light slowly sweeps across the glass from left to right, catching the bottle edges and making the amber juice glow as it passes, then settles back to soft daylight. Fine dust drifts in the light. Calm, premium, no other motion.

## 2. Slow push-in (5 s)

Camera pushes in slowly and evenly toward the bottle, about 10% closer by the end, ending on the cap and label. Soft daylight from the left stays constant. Shallow depth of field, background softly out of focus. No camera shake, no rotation.

## 3. Ingredient moment (4 s)

Static camera. Behind the bottle, out of focus, a halved fresh fig and a fig leaf slowly turn on the stone. The bottle stays perfectly still and sharp in the foreground. Warm morning light, gentle shadows.

## Keep out (negative prompt, where supported)

Changing bottle shape, extra bottles, warped or rewritten label text, cap color change, liquid sloshing, people, hands, fast motion, camera shake, flicker.

## Model notes

- **Sora / Veo:** paste the prompt as is and attach the first frame. Ask for 24 fps.
- **Kling:** image-to-video, Professional mode, motion strength low. Paste "Keep out" into the negative prompt.
- **Runway:** image-to-video with the first frame; set camera motion to static for prompts 1 and 3, push-in for prompt 2.
- After generation, check every frame for label drift. If the label warps, mask it and composite the label from the render back in After Effects with a planar track.

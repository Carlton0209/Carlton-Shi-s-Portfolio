# DAYMARK — Email design / 邮件设计项目

Independent portfolio concept, created 2026-10-24. DAYMARK is a fictional coffee brand. No campaign was sent and no conversion result is claimed. Product/lifestyle visuals are AI-assisted; prompts are in IMAGE-PROMPTS.json.

- Website case: https://carlton0209.github.io/Carlton-Shi-s-Portfolio/works/daymark-email
- Native Figma project: https://www.figma.com/design/RoctkyFhNcQ8G35C7NfQV2/?node-id=25-271
- Figma page: DAYMARK / Email design

## Files

- templates/: three merge-field HTML email sources, with live text and links.
- preview/: resolved browser examples with relative local JPG images. Open welcome.html, product.html or preferences.html in a browser. Preview links point to the portfolio case and do not change subscriptions.
- plain-text/: corresponding text alternatives; personalize and resolve fields along with HTML.
- assets/: product.jpg and ritual.jpg are the optimized email images. The full project also retains original PNGs.
- content.json: subject, preview text, body copy, CTA, image alt text, goals, rules, and untested subject proposals.
- config.example.json: generic merge values; adapt the syntax to the chosen ESP.
- manifest.json: metadata and exact UTF-8 template source bytes (images excluded; before ESP processing).
- COMPATIBILITY.md: implementation choices and actual testing limits.
- DAYMARK_Email_Design.pdf and figma/: native design review exports, included in the full project.

## Proposed sequence

1. Welcome after confirmed signup: introduce the brand and invite a product visit.
2. Product spotlight on Day 3: only while subscribed and no purchase is recorded.
3. Preference reset after 30 days without a click or purchase: one invitation to choose relevant content.

Purchase or unsubscribe exits the sequence. After a further 14 inactive days, suppress future promotional messages. These are proposed lifecycle rules, not an active automation. Validate timing and segmentation with real subscriber behavior.

## Integrating the source

Upload the JPGs to a verified HTTPS asset host and set asset_base_url. Set a relevant cta_url for each message. Replace first_name with the ESP's personalization syntax and provide a sensible fallback. Map preferences_url, unsubscribe_url and webview_url to the ESP's actual hosted endpoints/merge tags. Replace postal_address with the real sender address. Resolve the same variables in the plain-text version. Keep unsubscribe/preferences links readable. Templates do not contain scripts, forms or sending code.

The website's Light/Dark and Images on/off switches are browser review tools. The files themselves include prefers-color-scheme CSS; real clients may transform colors or ignore that CSS. The images-off review class hides the image and reveals a descriptive panel. It is a simulation; a real client may display native alt text differently.

## Figma handoff

Six native email variants cover three messages at 640 px desktop and 375 px mobile. Shared photography, header, footer, CTA and feature modules are native components. CTA labels expose a text property. Two variable collections provide primitive values and semantic Light/Dark aliases; the document contains 62 variables and 8 text styles.

Figma uses Arimo and Tinos, which are available to the connected account. HTML uses Arial/Helvetica and Times New Roman/Times system stacks. Font metrics can differ. Native design boards and HTML renders are both supplied so the implementation can be reviewed directly.

## 如何在作品集中介绍

可以表述为：“DAYMARK 是自主发起的邮件设计概念项目。我围绕虚构咖啡品牌，设计欢迎、产品推荐、偏好重设三封邮件，建立桌面与手机端 Figma 组件系统，并制作响应式 HTML 与纯文本交付，完成浏览器适配及图片关闭场景检查。”

不要将其写成真实客户合作、已上线营销自动化、已经完成邮件客户端兼容测试，或已有点击率／转化率提升。主题行 A/B 为待验证方案。

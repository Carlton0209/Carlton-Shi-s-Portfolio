# Rendering & verification

The deliverables use presentation tables, inline styles, a 640 px fluid container, a 620 px mobile breakpoint, image alt text, hidden preheaders, and a 48 px primary CTA. MSO conditional fixed-width wrappers, pixel-density settings, and VML buttons are included as implementation accommodations; the presence of markup is not a rendering test.

## Completed checks

- All three HTML files rendered in Chromium at 320, 375 and 640 px: no horizontal overflow; primary CTA height is 48 px; image sources load; no scripts.
- All three emails checked with forced dark CSS and an images-off simulation. Live heading, CTA and footer remain available.
- Six native Figma instances checked for zero-height/out-of-frame text. None found. CTA property override was applied and restored. Native Light/Dark specimens were visually reviewed.
- Website preview controls, mobile layouts, downloads and production links are checked separately in the website verification report.

## Remaining validation before a real send

No Gmail, Outlook, Apple Mail, other actual email clients, email-client screenshot suite, assistive technology, ESP integration, delivery, tracking, or inbox-placement test was performed. Fonts and dark-mode handling differ between clients. Test the final ESP-processed payload and links, not only the source files. Use an actual sender identity, subscriber preferences and suppression logic when integrating.

The template HTML source is about 9.5 KB each, excluding images. ESP processing can alter final message size. Mailchimp documents Gmail clipping around 102 KB, but a source-size check alone does not establish delivered-message behavior.

## Primary references

- Mailchimp, client-specific CSS: https://templates.mailchimp.com/development/css/client-specific-styles/
- Mailchimp, Gmail clipping: https://mailchimp.com/help/gmail-is-clipping-my-email/
- Can I Email, prefers-color-scheme support: https://www.caniemail.com/features/css-at-media-prefers-color-scheme/

References support implementation choices; they do not substitute for testing these templates in real email clients.
